# Lottie play on click

A Pen created on CodePen.io. Original URL: [https://codepen.io/useAnimations/pen/VOJEEm](https://codepen.io/useAnimations/pen/VOJEEm).

